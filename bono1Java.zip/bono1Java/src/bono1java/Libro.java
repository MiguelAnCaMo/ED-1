package bono1java;

/**
 *
 * @author migue
 */
public class Libro {
    //atributos del libro
    private int uuid;
    private String autor;
    private String titulo;
    private String categoria;

    public Libro(int uuid, String autor, String titulo, String categoria) {
        this.uuid = uuid;
        this.autor = autor;
        this.titulo = titulo;
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "Libro{" + "uuid=" + uuid + ", autor=" + autor + ", titulo=" + titulo + ", categoria=" + categoria + '}';
    }

    public int getUuid() {
        return uuid;
    }

    public String getCategoria() {
        return categoria;
    }

    public String getTitulo() {
        return titulo;
    }
        
    
}
