package bono1java;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author migue
 */
public class Archivo {

    private static int uuidCounter = 1;
    private String ruta;

    //estructura hashmap para guardar los uuids e informacion del libro, esta contiene libros
    private HashMap<Integer, Libro> libros = new HashMap<>();

    //lista para guardar libros ordenados alfabeticamente
    private ArrayList<Libro> librosOrdenados = new ArrayList<>();

    public Archivo(String ruta) {
        this.ruta = ruta;
    }
    Scanner sc = new Scanner(System.in);

    public void agregarLibro() throws IOException {
        int tempid;
        String titulo, autor, categoria;
        //crea archivo si este no existe
        File archivoLibros = new File(ruta);
        BufferedWriter bw;
        if (archivoLibros.exists()) {
        } else {
            bw = new BufferedWriter(new FileWriter(archivoLibros));
            bw.close();
        }
        //leer todos los componentes del libro y ponerlos separados por coma en una linea del .txt
        try (FileWriter writer = new FileWriter(ruta, true)) {
            writer.write("\n");
            writer.write(uuidCounter + ", ");
            System.out.println("Escribe el contenido del libro: \n Titulo ");
            titulo = sc.nextLine();
            writer.write(titulo + ", ");
            System.out.println("Autor o autores:");
            autor = sc.nextLine();
            writer.write(autor + ", ");
            System.out.println("Categoria:");
            categoria = sc.nextLine();
            writer.write(categoria);
            writer.write("\n");

            // Crear instancia del libro y agregarlo al HashMap
            Libro libro = new Libro(uuidCounter, titulo, autor, categoria);
            libros.put(uuidCounter, libro);
            uuidCounter++;

            System.out.println("Libro agregado correctamente");

        } catch (IOException e) {
            System.out.println("Error");
        }
    }

    //buscar libro por codigo unico
    public Libro buscarPorISBN() {
        int tempUUID;
        System.out.println("Digite el codigo del libro, minimo desde 1:");
        tempUUID = sc.nextInt();
        if (libros.containsKey(tempUUID)) {
            System.out.println(libros.get(tempUUID));
        }
        return null;
    }

    //buscar 1 o mas libros con la categoria deseada
    public void buscarPorCategoria() {
        String tempCategoria;
        System.out.println("Escribe la categoria a buscar:");
        tempCategoria = sc.nextLine();
        boolean encontrado = false;
        System.out.println("Libros en categoria " + tempCategoria + ":");
        for (Libro libro : libros.values()) {
            if (libro.getCategoria().trim().equalsIgnoreCase(tempCategoria.trim())) {
                System.out.println(libro);
                encontrado = true;
            }
        }

        if (!encontrado) {
            System.out.println("No se encontraron libros con esa categoria: (");
        }
    }

    //carga los datos del .txt y los guarda en un HashMap 
    public void cargarLibrosEnHashMap() {
        try (BufferedReader reader = new BufferedReader(new FileReader("D:\\Proyectos NetBeans\\bono1Java\\src\\bono1java\\libros.txt"))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(", ");
                if (partes.length == 4) {
                    int uuid = Integer.parseInt(partes[0]);
                    String titulo = partes[1];
                    String autor = partes[2];
                    String categoria = partes[3];

                    Libro libro = new Libro(uuid, titulo, autor, categoria);
                    libros.put(uuid, libro);

                    //agrega a lista para ordenar
                    librosOrdenados.add(libro);
                    uuidCounter = Math.max(uuidCounter, uuid + 1);

                }
            }
        } catch (IOException e) {
            System.out.println("No se encontro el archivo : (");
        }
    }

    //metodo para mostrar libros ordenados por titulo
    public void ordenarLibros() {

        //metodo para ordenar por titulo
        Collections.sort(librosOrdenados, Comparator.comparing(Libro::getTitulo, String.CASE_INSENSITIVE_ORDER));
        System.out.println("Libros ordenados alfabeticamente por titulo:");
        for (Libro libro : librosOrdenados) {
            System.out.println(libro);
        }
    }
}
