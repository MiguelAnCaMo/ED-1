package bono1java;

import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author migue
 */
public class Bono1Java {

    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);

        Archivo archivoLibros = new Archivo("D:\\Proyectos NetBeans\\bono1Java\\src\\bono1java\\libros.txt");

        boolean run = true;
        int opcion;

        while (run == true) {
            //cargando el.txt por si hay informacion de algun libro
            archivoLibros.cargarLibrosEnHashMap();

            System.out.println("""
                               Digite opcion: 
                                1. Agregar libro 
                                2. Consultar libro por codigo unico 
                                3. Consultar libro(s) por categorias 
                                4. Consultar por orden alfabetico con titulos: """);
            opcion = sc.nextInt();
            //switch para las opciones para ingresar
            switch (opcion) {
                case 1:
                    archivoLibros.agregarLibro();
                    break;
                case 2:
                    archivoLibros.buscarPorISBN();
                    break;
                case 3:
                    archivoLibros.buscarPorCategoria();
                    break;
                case 4:
                    //archivoLibros.cargarLibrosEnHashMap();
                    archivoLibros.ordenarLibros();
                    break;
            }
        }

    }

}
